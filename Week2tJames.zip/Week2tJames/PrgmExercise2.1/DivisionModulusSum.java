/**Program: Sum of five numbers
 * File: DivisionModulusSum
 * Summary: Uses % and / to find the sum of 5 user inputed numbers
 * Author: Tim James
 * Date: October 11, 2017
 */
// Imports the Scanner utility
import java.util.*;

public class DivisionModulusSum {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Prompts the user to enter a five digit number
        System.out.print("Enter a 5-digit positive integer: ");
        int number = input.nextInt();
        
        int remainder = number;
        
        // Find the first number
        int firstNumber = number / 10000;
        remainder = remainder % 10000;
        
        // Find second number
        int secondNumber = remainder / 1000;
        remainder = remainder % 1000;
        
        // Find third number
        int thirdNumber = remainder / 100;
        remainder = remainder % 100;
        
        // Find fourth number, remainder is the fifth number
        int fourthNumber = remainder / 10;
        remainder = remainder % 10;
        
        // Computes the sum of all numbers
        int sum = firstNumber + secondNumber + thirdNumber + fourthNumber + remainder;
        
        // Prints the sum to the console
        System.out.println("The sum of " + firstNumber + " + " + secondNumber + 
                " + " + thirdNumber + " + " + fourthNumber + " + " +
                        remainder + " is: " + sum);
    }
}
