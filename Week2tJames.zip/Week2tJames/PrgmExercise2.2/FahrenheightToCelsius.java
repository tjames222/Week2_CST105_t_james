/** Program: Fahrenheit to Celsius converter
 * File: FahrenheightToCelsius.java
 * Summary: Converts Fahrenheit to Celsius and then does the opposite
 * Author: Tim James
 * Date: October 10, 2017
 */

// Imports the java utility package which includes the Scanner
import java.util.*;

public class FahrenheightToCelsius {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Prompts user to enter a degree in Fahrenheit
        System.out.print("Enter a degree in Fahrenheit: ");
        double fahrenheit = input.nextDouble();
        
        // Convert Fahrenheit to Celsius
        double celsius = (5.0 / 9) * (fahrenheit - 32);
        System.out.println("Fahrenheit " + fahrenheit + " is " +
                celsius + " in Celsius");
        
        // Prompts the user to enter a degree in Celsius
        System.out.print("Enter a degree in Celsius: ");
        double celsiusIn = input.nextDouble();
        
        // Converts Celsius to Fahrenheit
        double fahrenheitOut = celsiusIn * 9 / 5.0 + 32;
        System.out.println("Celsius " + celsiusIn + " is " +
                fahrenheitOut + " in Fahrenheit");     
        
    }
}
